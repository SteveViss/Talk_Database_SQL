Talk_Database_SQL
=================

A quick talk on how structure and conserve data 

## Data conservation: Perspectives, issues and solutions

**Authors:** Miranda Talluto and Steve Vissault

#### 1. Conventionnal way to store data 

- Text file
- CSV file
- Excel fiel

In charge: Steve 

#### 2. Why do something different ? 

- Sotaert paper 

In charge: Steve 

#### 3. About lost data 

- See [article](http://www.nature.com/news/scientists-losing-data-at-a-rapid-rate-1.14416) in Nature Journal
- Add some statistic

In charge: Steve

#### 4. How to do something different ? 

- Define relationnal database (RDB)

In charge: Miranda

#### 5. How to create a relationnal database 

- SQL langage presentation

In charge: Miranda

#### 6. Some queries (basic example)

In charge: Miranda

#### 7. Exportability of SQL

- R
- Python
- PostGIS and QGIS

In charge: Miranda

#### 8. What is available at UQAR ?

- Plateform accessible
- Security and back-up procedure

In charge: James

#### 9. OpenData discussion

What should be the conventionnal way !
Draw a diagram illustrating this one.

In charge: Steve

